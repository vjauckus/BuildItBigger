package com.android.udacity.vjauckus.jokewizard;

public class JokeWizard {

    public static String getJoke(){

        return "Q: What is black, white, and red all over?\nA: A sun burnt penguin.";
    }
}
